USE DemoDb
GO

SET implicit_transactions ON

CREATE TABLE a (a INT, b VARCHAR(100))
GO


INSERT INTO a VALUES (9, 'Brees')

