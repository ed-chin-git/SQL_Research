USE DemoDb

SELECT * FROM a 

